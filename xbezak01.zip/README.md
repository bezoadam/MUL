## Prehrávač a editor ID3 tagov v MP3 súboroch

####Spustenie:
`python3 install -r requirements.txt`
`python3 mp3_player.py`

####Autori:
`Adam Bezak - xbezak01`
`Jan Stratil - xtrat10`